import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
// 🔄 ĐỔI TÊN: Sửa đường dẫn import cho đúng với project của bạn
import 'package:todo_test/providers/todo_provider.dart';

// 🔄 ĐỔI TÊN: Đổi AddTodoScreen thành tên màn hình tương ứng
// 💡 GỢI Ý ĐỔI THEO ĐỀ:
// - Đề Sinh viên: class AddSinhVienScreen extends StatefulWidget
// - Đề Thư viện: class AddSachScreen extends StatefulWidget
// - Đề Chi tiêu: class AddChiTieuScreen extends StatefulWidget
class AddTodoScreen extends StatefulWidget {
  const AddTodoScreen({super.key});

  @override
  State<AddTodoScreen> createState() => _AddTodoScreenState();
}

class _AddTodoScreenState extends State<AddTodoScreen> {
  final _controller = TextEditingController();

  // Tạo key 
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // 🔄 ĐỔI TÊN: Thay đổi tiêu đề AppBar cho khớp đề bài
        // 💡 GỢI Ý: "Thêm sinh viên", "Thêm sách", "Thêm khoản chi"
        title: Text("Thêm công việc"),
      ),

      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _controller,
                decoration: InputDecoration(
                  // 🔄 ĐỔI TÊN: Thay đổi nhãn hướng dẫn nhập liệu
                  // 💡 GỢI Ý: "Nhập họ tên sinh viên: ", "Nhập tên sách: ", "Nhập tên khoản chi: "
                  labelText: "Nhập tên công việc: ",
                  border: OutlineInputBorder()
                ),

                // Kiểm tra lỗi
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return "Không được để trống!";
                  }
                  // ❌ XÓA NẾU KHÔNG DÙNG: Xóa khối check length < 5 này đi nếu đề thi không yêu cầu độ dài tối thiểu
                  if (value.length < 5) {
                    return "Tên phải lớn hơn 5 kí tự";
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              
              // ❌ THÊM NẾU CẦN: Nếu đề bài yêu cầu nhập thêm trường Bool (như Checkbox Giới tính, Trạng thái), 
              // hãy thêm một CheckboxListTile hoặc SwitchListTile ở đây.

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        // 🔄 ĐỔI TÊN: TodoProvider và addTodos thành tên Provider và hàm tương ứng
                        // 💡 GỢI Ý:
                        // - Provider.of<SinhVienProvider>(context, listen: false).addSinhVien(_controller.text);
                        // - Provider.of<SachProvider>(context, listen: false).addSach(_controller.text);
                        Provider.of<TodoProvider>(
                          context,
                          listen: false,
                        ).addTodos(_controller.text);

                        Navigator.pop(context);
                      }
                    }, 
                    child: Text("Lưu")
                  ),

                  SizedBox(width: 20,),
                  
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    }, 
                    child: Text("Hủy")
                  )
                ],
              )
            ],
          ),
        ),
      )
    );
  }
}
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

// 🔄 ĐỔI TÊN: Sửa đường dẫn import cho đúng
// 💡 GỢI Ý ĐỔI THEO ĐỀ: import 'package:todo_test/providers/sinh_vien_provider.dart';
import 'package:todo_test/providers/todo_provider.dart';
import 'package:todo_test/screens/add_todo_screen.dart';

// 🔄 ĐỔI TÊN: Đổi TodoListScreen thành tên màn hình tương ứng
// 💡 GỢI Ý ĐỔI THEO ĐỀ:
// - Đề Sinh viên: class SinhVienListScreen extends StatefulWidget
// - Đề Thư viện: class SachListScreen extends StatefulWidget
// - Đề Chi tiêu: class ChiTieuListScreen extends StatefulWidget
class TodoListScreen extends StatefulWidget {
  const TodoListScreen({super.key});
  @override
  State<TodoListScreen> createState() => _TodoListScreenState();
}

class _TodoListScreenState extends State<TodoListScreen> {
  @override
  void initState() {
    super.initState();
    // 🔄 ĐỔI TÊN: TodoProvider và hàm loadTodos
    // 💡 GỢI Ý ĐỔI THEO ĐỀ: 
    // - Provider.of<SinhVienProvider>(context, listen: false).loadSinhViens();
    // - Provider.of<SachProvider>(context, listen: false).loadSachs();
    Provider.of<TodoProvider>(context, listen: false).loadTodos();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // 🔄 ĐỔI TÊN: Thay đổi tiêu đề
        // 💡 GỢI Ý ĐỔI THEO ĐỀ: "Quản lý Sinh viên", "Quản lý Thư viện sách", "Quản lý Chi tiêu"
        title: Text("Quản lý công việc"),
        
        // ❌ XÓA NẾU KHÔNG DÙNG: Toàn bộ khối 'bottom' này là thanh tìm kiếm. Xóa nếu đề không yêu cầu.
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(80),
          child: Padding(
            padding: EdgeInsets.all(15),
            child: TextField(
              decoration: InputDecoration(
                // 🔄 ĐỔI TÊN: Text tìm kiếm
                // 💡 GỢI Ý ĐỔI THEO ĐỀ: "Tìm kiếm sinh viên...", "Tìm kiếm sách..."
                hintText: "Tìm kiếm ....",
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                contentPadding: EdgeInsets.symmetric(horizontal: 10),
                prefixIcon: Icon(Icons.search),
              ),
              onChanged: (value) {
                // 🔄 ĐỔI TÊN: TodoProvider và hàm tìm kiếm (searchTodoss)
                // 💡 GỢI Ý ĐỔI THEO ĐỀ: 
                // - Provider.of<SinhVienProvider>(...).searchSinhVien(value);
                Provider.of<TodoProvider>(
                  context,
                  listen: false,
                ).searchTodoss(value);
              },
            ),
          ),
        ),
        
        // ❌ XÓA NẾU KHÔNG DÙNG: Toàn bộ khối 'actions' này là Menu lọc góc trên bên phải. Xóa nếu đề không yêu cầu.
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == "all") {
                // 🔄 ĐỔI TÊN: TodoProvider và hàm load
                // 💡 GỢI Ý: Provider.of<SinhVienProvider>(context, listen: false).loadSinhViens();
                Provider.of<TodoProvider>(context, listen: false).loadTodos();
              } else if (value == "completed") {
                // 🔄 ĐỔI TÊN: TodoProvider và hàm load chưa hoàn thành (hoặc Nam/Thu nhập)
                // 💡 GỢI Ý: Provider.of<SinhVienProvider>(context, listen: false).loadSinhVienNam();
                Provider.of<TodoProvider>(context, listen: false).loadTodoNotfinish();
              } else {
                // 🔄 ĐỔI TÊN: TodoProvider và hàm load đã hoàn thành (hoặc Nữ/Chi tiêu)
                // 💡 GỢI Ý: Provider.of<SinhVienProvider>(context, listen: false).loadSinhVienNu();
                Provider.of<TodoProvider>(context, listen: false).loadTodofinish();
              }
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                value: "all",
                child: Text("Tất cả"),
              ),
              PopupMenuItem(
                value: "completed",
                // 🔄 ĐỔI TÊN: Đổi text hiển thị
                // 💡 GỢI Ý ĐỔI THEO ĐỀ: "Đã tốt nghiệp" / "Sinh viên Nữ" / "Đã cho mượn" / "Khoản chi"
                child: Text("Đã làm"),
              ),
              PopupMenuItem(
                value: "pending",
                // 🔄 ĐỔI TÊN: Đổi text hiển thị
                // 💡 GỢI Ý ĐỔI THEO ĐỀ: "Chưa tốt nghiệp" / "Sinh viên Nam" / "Sẵn trong kho" / "Khoản thu"
                child: Text("Chưa làm"),
              ),
            ],
          ),
        ],
      ),

      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            // 🔄 ĐỔI TÊN: AddTodoScreen thành tên màn hình Add của bạn 
            // 💡 GỢI Ý ĐỔI THEO ĐỀ: AddSinhVienScreen(), AddSachScreen()
            MaterialPageRoute(builder: (_) => AddTodoScreen()),
          );
        },
      ),

      // 🔄 ĐỔI TÊN: TodoProvider
      // 💡 GỢI Ý ĐỔI THEO ĐỀ: Consumer<SinhVienProvider>, Consumer<SachProvider>
      body: Consumer<TodoProvider>(
        builder: (context, provider, child) {
          if (provider.todos.isEmpty) {
            // 🔄 ĐỔI TÊN: Đổi text thông báo rỗng
            // 💡 GỢI Ý ĐỔI THEO ĐỀ: "Danh sách sinh viên trống!", "Chưa có sách nào!"
            return Center(child: Text("Chưa có công việc nào!"));
          }
          return ListView.builder(
            itemBuilder: (context, index) {
              // 🔄 ĐỔI TÊN: todo -> sinhVien / sach / chiTieu
              // 💡 GỢI Ý ĐỔI THEO ĐỀ: final sv = provider.sinhViens[index];
              final todo = provider.todos[index];
              
              // ❌ XÓA NẾU KHÔNG DÙNG: Tính năng vuốt để xóa Dismissible. Nếu đề không yêu cầu xóa, bạn chỉ cần return nguyên khối ListTile ở bên trong.
              return Dismissible(
                // 🛠️ ĐÃ SỬA LỖI: Dùng dấu '!' vì id ở Model đang là kiểu int? (có thể null)
                key: Key(todo.id!.toString()),
                background: Container(
                  color: Colors.red,
                  alignment: Alignment.centerRight,
                  child: Icon(Icons.delete, color: Colors.white),
                ),
                direction: DismissDirection.endToStart,

                onDismissed: (direction) {
                  // 🔄 ĐỔI TÊN: Hàm xóa trong Provider
                  // 💡 GỢI Ý ĐỔI THEO ĐỀ: provider.removeSinhViens(sv.id!)
                  provider.removeTodos(todo.id!);

                  // Hiện thông báo SnackBar
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      // 🔄 ĐỔI TÊN: Text hiển thị sau khi xóa
                      // 💡 GỢI Ý ĐỔI THEO ĐỀ: "Đã xóa sinh viên '${sv.hoTen}'", "Đã xóa sách '${sach.tenSach}'"
                      content: Text("Đã xóa '${todo.title}'"),
                      // ❌ XÓA NẾU KHÔNG DÙNG: Tính năng khôi phục Undo
                      action: SnackBarAction(label: "Khôi phục", onPressed: () {
                        // 🔄 ĐỔI TÊN: Hàm Undo nếu có
                        provider.undoDelete();
                      }),
                    ),
                  );
                },
                // Xác nhận trước khi xóa
                confirmDismiss: (direction) async {
                  return showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text("Xác nhận"),
                        // 🔄 ĐỔI TÊN: Text xác nhận
                        // 💡 GỢI Ý ĐỔI THEO ĐỀ: "Bạn có chắc muốn xóa sinh viên này không?", "Bạn có chắc muốn xóa sách này không?"
                        content: Text("Bạn có chắc muốn xóa công việc này không?"),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.of(context).pop(false),
                            child: Text("Hủy"),
                          ),
                          TextButton(
                            onPressed: () => Navigator.of(context).pop(true),
                            child: Text(
                              "Xóa",
                              style: TextStyle(color: Colors.red),
                            ),
                          ),
                        ],
                      );
                    },
                  );
                },
                child: ListTile(
                  title: Text(
                    // 🔄 ĐỔI TÊN: Đổi title thành thuộc tính bạn muốn hiển thị 
                    // 💡 GỢI Ý ĐỔI THEO ĐỀ: sv.hoTen, sach.tenSach, chiTieu.tenKhoanChi
                    todo.title,
                    style: TextStyle(
                      // ❌ XÓA NẾU KHÔNG DÙNG: Xóa hiệu ứng gạch ngang nếu là đề Sinh Viên, Chi tiêu
                      decoration: todo.status ? TextDecoration.lineThrough : null,
                      color: todo.status ? Colors.grey : Colors.black,
                    ),
                  ),

                  leading: Checkbox(
                    // 🔄 ĐỔI TÊN: todo.status -> sv.isNu, sach.coSan
                    value: todo.status,
                    onChanged: (val) {
                      // 🔄 ĐỔI TÊN: Gọi hàm trong provider để đổi trạng thái
                      // 💡 GỢI Ý ĐỔI THEO ĐỀ: provider.toggleGioiTinh(sv.id!)
                      provider.toggleStatus(todo.id!);
                    },
                  ),
                ),
              );
            },
            itemCount: provider.todos.length,
          );
        },
      ),
    );
  }
}
import 'package:sqflite/sqflite.dart';
// 🔄 ĐỔI TÊN: Sửa đường dẫn import cho đúng với tên project của bạn
import 'package:todo_test/data/datahelper.dart';
import 'package:todo_test/model/todo_model.dart';

// 🔄 ĐỔI TÊN: Đổi TodoRepository thành tên tương ứng đề bài (VD: BookRepository)
class TodoRepository {
  final DatabaseHelper  _data = DatabaseHelper();

  // Lấy toàn bộ danh sách
  // 🔄 ĐỔI TÊN: Đổi chữ Todo thành Class Model của bạn (VD: Book)
  Future<List<Todo>> getTodos() async {
    final db = await _data.database;
    // 🔄 ĐỔI TÊN: 'todos' thành tên bảng của đề bài (VD: books, students)
    final List<Map<String, dynamic>> maps = await db.query('todos');

    return List.generate(maps.length, (i) => Todo.fromMap(maps[i]));
  }

  // ❌ XÓA NẾU KHÔNG DÙNG: Hàm lọc danh sách True (Đã hoàn thành)
  Future<List<Todo>> getStatusTrue() async {
    final db = await _data.database;
    // 🔄 ĐỔI TÊN: 'todos' thành tên bảng
    final List<Map<String, dynamic>> maps = await db.query(
      'todos',
      where: 'status = 1',
    );
    return List.generate(maps.length, (o) => Todo.fromMap(maps[o]));
  }

  // ❌ XÓA NẾU KHÔNG DÙNG: Hàm lọc danh sách False (Chưa hoàn thành)
  Future<List<Todo>> getStatusFalse() async {
    final db = await _data.database;
    // 🔄 ĐỔI TÊN: 'todos' thành tên bảng
    final List<Map<String, dynamic>> maps = await db.query(
      'todos',
      where: 'status = 0',
    );
    return List.generate(maps.length, (o) => Todo.fromMap(maps[o]));
  }

  // Thêm mới
  Future<void> insertTodo(Todo todo) async {
    final db =  await _data.database;
    // 🔄 ĐỔI TÊN: 'todos' thành tên bảng
    await db.insert(
      'todos', 
      todo.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace, // Nếu trùng id sẽ ghi đè 
    );
  }

  // Cập nhật
  Future<void> updateTodo(Todo todo) async {
    final db = await _data.database;
    // 🔄 ĐỔI TÊN: 'todos' thành tên bảng
    await db.update(
      'todos', 
      todo.toMap(),
      where: 'id = ?',
      whereArgs: [todo.id],
    );
  }

  // Xóa 
  Future<void> deleteTodo(int id) async {
    final db = await _data.database;
    // 🔄 ĐỔI TÊN: 'todos' thành tên bảng
    await db.delete(
      'todos',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // Tìm kiếm
  // ❌ XÓA NẾU KHÔNG DÙNG: Xóa toàn bộ hàm này nếu đề không yêu cầu tính năng tìm kiếm
  Future<List<Todo>> searchTodos(String keyw) async {
    final db = await _data.database;
    // 🔄 ĐỔI TÊN: 'todos' thành tên bảng | 'title' thành cột bạn muốn tìm (VD: tenSach, hoTen)
    final List<Map<String, dynamic>> maps = await db.query(
      'todos', 
      where: 'title LIKE ?',
      whereArgs: ['%$keyw%'],
    );

    return List.generate(maps.length, (i) => Todo.fromMap(maps[i]));
  }

  // Lọc (Viết gộp)
  // ❌ XÓA NẾU KHÔNG DÙNG: Đây là hàm lọc viết gộp cho tiện, bạn có thể truyền status (0 hoặc 1) vào để lọc. Nếu không dùng thì xóa đi.
  Future<List<Todo>> filterTodos(int statusValue) async {
    final db = await _data.database;
    // 🔄 ĐỔI TÊN: 'todos' thành tên bảng | 'status' thành tên cột cần lọc (VD: isNu, isExpense)
    final List<Map<String, dynamic>> maps = await db.query(
      'todos', 
      where: 'status = ?',
      whereArgs: [statusValue],
    );

    return List.generate(maps.length, (i) => Todo.fromMap(maps[i]));
  }
}
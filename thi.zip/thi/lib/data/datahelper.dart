import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();

  factory DatabaseHelper() => _instance;
  
  DatabaseHelper._internal();
  
  static Database? _database;

  // Hàm lấy database
  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    // Lấy đường dẫn thư mục lưu file
    // 🔄 ĐỔI TÊN: Thay 'todo_database.db' bằng tên file DB đề yêu cầu (VD: thuvien.db, sinhvien.db, chitieu.db)
    String path = join(await getDatabasesPath(), 'todo_database.db');

    return await openDatabase(
      path, 
      version: 1, 
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    // 🔄 ĐỔI TÊN: Thay 'todos' thành tên bảng của đề bài (VD: tblSach, tblSinhVien, tblChiTieu, tblCongViec)
    // ❌ XÓA NẾU KHÔNG DÙNG: Bạn có thể thêm hoặc bớt các dòng trong ngoặc đơn cho khớp với số lượng cột của đề thi
    await db.execute('''
      CREATE TABLE todos(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        status INTEGER
      )
    ''');
  }
}
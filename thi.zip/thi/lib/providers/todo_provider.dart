import 'package:flutter/material.dart';
// 🔄 ĐỔI TÊN: Sửa đường dẫn import cho đúng với project của bạn
import 'package:todo_test/data/todo_repository.dart';
import 'package:todo_test/model/todo_model.dart';

// 🔄 ĐỔI TÊN: Đổi TodoProvider thành tên Provider của bạn
// 💡 GỢI Ý ĐỔI THEO ĐỀ:
// - Đề Sinh viên: class SinhVienProvider extends ChangeNotifier
// - Đề Thư viện: class SachProvider extends ChangeNotifier
// - Đề Chi tiêu: class ChiTieuProvider extends ChangeNotifier
class TodoProvider extends ChangeNotifier {
  // Khởi tạo repo
  // 🔄 ĐỔI TÊN: TodoRepository thành tên Repo của bạn
  // 💡 GỢI Ý: SinhVienRepository(), SachRepository()
  final TodoRepository _repo = TodoRepository();
  
  // 🔄 ĐỔI TÊN: Todo thành tên Model của bạn
  // 💡 GỢI Ý ĐỔI THEO ĐỀ:
  // - _todos -> _sinhViens (Sinh viên)
  // - _todos -> _sachs (Thư viện)
  // - _todos -> _chiTieus (Chi tiêu)
  List<Todo> _todos = [];

  // ❌ XÓA NẾU KHÔNG DÙNG: Biến này dùng cho tính năng Khôi phục (Undo), xóa nếu đề không yêu cầu
  Todo? _lastDe;

  List<Todo> get todos => _todos;

  // Tải dữ liệu từ ổ cứng về
  Future<void> loadTodos() async {
    _todos = await _repo.getTodos();
    notifyListeners();
  }

  // ❌ XÓA NẾU KHÔNG DÙNG: Các hàm tải dữ liệu theo bộ lọc
  Future<void> loadTodofinish() async {
    _todos = await _repo.getStatusTrue();
    notifyListeners();
  }

  Future<void> loadTodoNotfinish() async {
    _todos = await _repo.getStatusFalse();
    notifyListeners();
  }

  // Thêm mới
  // 🔄 ĐỔI TÊN: Thêm/Sửa các tham số truyền vào cho khớp với Model
  // 💡 GỢI Ý ĐỔI THEO ĐỀ:
  // - Đề Công việc: addTodos(String title, bool status)
  // - Đề Sinh viên: addSinhVien(String hoTen, bool isNu)
  // - Đề Thư viện: addSach(String tenSach, bool coSan)
  // - Đề Chi tiêu: addChiTieu(String tenKhoanChi, bool laKhoanChi)
  Future<void> addTodos(String title) async {
    final newTodo = Todo(
      title: title,
      status: false,
    );

    // Lưu xuống database
    await _repo.insertTodo(newTodo);

    // Reload lại trang
    await loadTodos();
  }

  // Sửa trạng thái (Đảo ngược True/False)
  // 💡 GỢI Ý ĐỔI THEO ĐỀ:
  // - toggleStatus -> toggleGioiTinh (Sinh viên)
  // - toggleStatus -> toggleTrangThaiSach (Thư viện)
  Future<void> toggleStatus(int id) async {
    final index = _todos.indexWhere((m) => m.id == id);
    if (index != -1) {
      final todo = _todos[index];

      // Đảo ngược trạng thái
      // 🔄 ĐỔI TÊN:
      // - todo.status = !todo.status
      // - sv.isNu = !sv.isNu (Sinh viên)
      // - sach.coSan = !sach.coSan (Thư viện)
      todo.status = !todo.status;

      await _repo.updateTodo(todo);
      await loadTodos();
    }
  }

  // Xóa
  Future<void> removeTodos(int id) async {
    final index = _todos.indexWhere((e) => e.id == id);
    if (index != -1) {
      _lastDe = _todos[index]; // Lưu tạm để có thể Khôi phục

      await _repo.deleteTodo(id);
      _todos.removeAt(index);
    }
    await loadTodos();
  }

  // Khôi phục
  // ❌ XÓA NẾU KHÔNG DÙNG: Tính năng Undo
  Future<void> undoDelete() async {
    if (_lastDe != null) {
      await _repo.insertTodo(_lastDe!);

      _todos.add(_lastDe!);

      _lastDe = null;
      notifyListeners();
    }
  }

  // Tìm kiếm
  // ❌ XÓA NẾU KHÔNG DÙNG: Tính năng tìm kiếm
  Future<void> searchTodoss(String keyw) async {
    if (keyw.isEmpty) {
      await loadTodos();
    } else {
      _todos = await _repo.searchTodos(keyw);
      notifyListeners();
    }
  }
}
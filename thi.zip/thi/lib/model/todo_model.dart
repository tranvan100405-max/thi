// 🔄 ĐỔI TÊN: Đổi tên class Todo thành tên Model của bạn (VD: Book, Student)
class Todo {
  int? id;
  
  String title;
  bool status;

  Todo({
    this.id,
    required this.title,
    this.status = false,
  }); 

  // Chuyển từ đối tượng sang Map để lưu vào SQLite
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'status': status ? 1 : 0, // Lưu trạng thái dưới dạng số nguyên (1 cho true, 0 cho false)
    };
  }

  // Chuyển từ Map của SQLite sang đối tượng
  factory Todo.fromMap(Map<String, dynamic> map) {
    return Todo(
      id: map['id'],
      title: map['title'],
      status: map['status'] == 1, // Chuyển đổi số nguyên về boolean
    );
  }
}
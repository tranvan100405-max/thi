
import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import 'package:todo_test/providers/todo_provider.dart';
import 'package:todo_test/screens/todo_list_screen.dart';

void main() {
  runApp(
    //đăng provider ở đỉnh cao nhất
    ChangeNotifierProvider(create: (context) => TodoProvider(),
    child: const MyApp(),)
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: TodoListScreen(),
    );
  }
}